<?php include("cabecalho.php");
include("conecta.php");
$nome = $_GET["nome"];
$preco = $_GET["preco"];

$query = "insert into produtos(nome, preco) values ('{$nome}' , {$preco})";
if(mysqli_query($conexao, $query)) {?>
<p class="alert alert-success">Produto <?= $nome;?>, <?= $preco;?> adicionado com sucesso!</p>
<?php } else {
	$msg=mysqli_error($conexao);
	?>
<p class="alert alert-warning">Produto não adicionado: <?= msg?> </p>
<?php
}
?>
<?php include("rodape.php");?>