<?php include("cabecalho.php");?>
				<h1>Bem Vindo!</h1>
<?php include("rodape.php");?>