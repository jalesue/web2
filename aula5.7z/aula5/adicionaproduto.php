<?php include("cabecalho.php");
include("conecta.php");
$nome = $_POST["nome"];
$preco = $_POST["preco"];
$descricao = $_POST["descricao"];

$query = "insert into produtos(nome, preco, descricao) values 
('{$nome}' , {$preco}, '{$descricao}')";
if(mysqli_query($conexao, $query)) {?>
<p class="alert alert-success">Produto <?= $nome;?>, <?= $preco;?> 
adicionado com sucesso!</p>
<?php } else {
	$msg=mysqli_error($conexao);
	?>
<p class="alert alert-warning">Produto não adicionado: <?= msg?> </p>
<?php
}
?>
<?php include("rodape.php");?>