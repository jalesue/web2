<html>
<head>
	<meta charset="utf-8">
	<title>Minha Loja</title>
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/loja.css" rel="stylesheet">
</head>
<body>
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="container">
				<div class="navbar-header">
				<a class="navbar-brand" href="index.php"> Minha Loja </a>
				</div>
			<div>
				<ul class="nav navbar-nav">
			<li><a href="produtoformulario.php"> Adiciona Produto</a></li>
					<li><a href="sobre.php">Sobre</a></li>
				</ul>
			</div>
			<form class="navbar-form navbar-left">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
		</div>
			</div>

		<div class="container">
			<div class="principal">