<?php
function listaprodutos($conexao) {
	$produtos = array();
	$resultado = mysqli_query($conexao, "select * from produtos");
	while($produto = mysqli_fetch_assoc($resultado)) {
		array_push($produtos, $produto);
}
	return $produtos;
}